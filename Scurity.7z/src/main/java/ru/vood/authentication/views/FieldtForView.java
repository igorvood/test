package ru.vood.authentication.views;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;

public class FieldtForView<T> {
    private Class<T> type;

    public FieldtForView(Class<T> type) {
        this.type = type;
    }

    public Map<String, String> getListFields() {
        final Map<String, String> collect = Arrays.stream(type.getDeclaredFields())
                .filter(field -> (field.getAnnotation(ViewColumn.class) != null))
                .collect(Collectors.toMap(Field::getName, o -> getDisplayName(o)));
        return collect;
    }

    private String getDisplayName(Field field) {
        final Annotation ann = Arrays.stream(field.getAnnotations())
                .filter(annotation -> annotation.annotationType().equals(ViewColumn.class))
                .findFirst().orElse(null);
        if (ann != null) {
            return ((ViewColumn) ann).displayName();
        }
        return "";
    }
}
